//********************************************************************************
// GettingSumImplements.java
//
// Name:Anfal AlYousufi
// Date: 14th of nov 2015
//
//********************************************************************************



public class GettingSumImplements {
   public static void main(String[] args)
    {
       ImplementingSum obj = new ImplementingSum();
       int x = 10;
       int y = 20;
       int z = 30;   // x + y = 30....yay?
       System.out.println("Calling Getting sum implements " + obj.sum(x, y,z));
       System.out.println("Calling Getting sum implements " + obj.sum(x, y,y));
       System.out.println("Calling Getting sum implements " + obj.sum(x,x,x));
       System.out.println("Calling Getting sum implements " + obj.sum(y, y,z));
       System.out.println("Calling Getting sum implements " + obj.sum(z, z,z));
       
       System.out.println("Calling Getting multiplication implements " + obj.multiply(x, y,z));
       System.out.println("Calling Getting multiplication implements " + obj.multiply(x, y,y));
       System.out.println("Calling Getting multiplication implements " + obj.multiply(x,x,x));
       System.out.println("Calling Getting multiplication implements " + obj.multiply(y, y,y));
       System.out.println("Calling Getting multiplication implements " + obj.multiply(z, z,z));
   }
 }

	
 