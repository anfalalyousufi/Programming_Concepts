//********************************************************************************
// DrivingSum.java
//
// Name:Anfal AlYousufi
// Date: 13th of Nov 2015
// LAB_09
//********************************************************************************


public class DrivingSum 
{
   public static void main(String[] args)
    {
       int x = 10;
       int y = 20; // x + y = 30....yay?
       ZeroSum zero = new ZeroSum();
       RealSum real = new RealSum();
       System.out.println("Calling ZeroSum " + zero.sum(x, y));
       System.out.println("Calling RealSum " + real.sum(x, y));
   }
}