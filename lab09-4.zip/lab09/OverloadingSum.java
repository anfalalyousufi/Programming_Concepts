//********************************************************************************
// OverloadingSum.java
//
// Name:Anfal AlYousufi
// Date: 14th of nov 2015
//
//********************************************************************************

//This class overloads the sum method several ways.

public class OverloadingSum {
	// int

  public int sum(int x, int y) {                       //1
		return x + y;
     }
   public int sum ( int y , short x ){                  //3
     return y + x ;
     }
	public int sum (int x, int y, int z) {               //2
      return x + y + z ;
	  }
   public int sum( int y , short x, short z ){           //4
     return y + x + z;
     }
    public int sum( int y , short x, int z ){            //5
     return y + x + z;
     }
   public int sum( int y , int x, short z ){            //6
     return y + x + z;
     }
  
   public int sum( short y , int x, int z ){            //7
     return y + x + z;
     }
   
   // short 
   public int sum( short y , int x, short z ){          //8
     return y + x + z;
     }
   public int sum( short y , short x, int z ){            //9
     return y + x + z;
     }
   public int sum( short y , short x ){                    //10
     return y + x ;
     }
   public int sum( short y , int x ){                    //11
     return y + x ;
     }
   public int sum( short y , short x , short z ){         //12
     return y + x +z ;
     }
 
     // float
   public float sum(short x, float y){             //13
     return y + x ;
     }
   
	public float sum(float x, short y){             //14
     return x + y ;
     }
	public float sum(float x, int y){               //15
     return x + y ;
     }
	public float sum(int x, float y){               //16
     return x + y ;
     }
	public float sum(float x, float y){             //17
     return x + y ;
     }
   public float sum ( float x , float y, float z ){       //18
     return x + y + z;
     }
   public float sum ( float x , int y, float z ){          //19
     return x + y + z;
     }
    public float sum ( float x ,short y, short z ){       //20
     return x + y + z;
     }
   public float sum ( float x ,int y, short z ){         //21
     return x + y + z;
     }
   public float sum ( float x , int y, int z ){          //22
     return x + y + z;
     }
   public float sum (short x, int y, float z){           //23
     return x + y + z;
       }
  public float sum(short x, float y, int z){             //24
     return x + y + z;
       }
  public float sum(int x, float y, short z){            //25
       return x + y + z;
       }
	public float sum(float x, short y, int z){            //26
       return x + y + z;
       }
   public float sum(short x, float y, float z){          //27
       return x + y + z;
       }
	public float sum(float x, short y, float z){           //28
       return x + y + z;
       }
	public float sum(float x, float y, short z){          //29
       return x + y + z;
       }
	public float sum(short x, short y, float z){             //30
       return x + y + z;
       }
	public float sum(short x, float y, short z){       //31
       return x + y + z;
       }
	public float sum(int x, short y, float z){            //32
       return x + y + z;
       }
	
	 // double
   public double sum(int y, short x, double z){          //33
     return y + x + z;
     }
   public double sum(double y, int x, short z){            //34
     return y + x + z;
     }
   public double sum(double y, int x){                   //35
     return y + x ;
     }
   public double sum(int y, double x){                //36
     return y + x ;
     }
   public double sum(double y, short x){              //37
     return y + x ;
     }
  public double sum(int y, double x, double z){       //38
     return y + x + z;
     }
  public double sum(int y, double x, int z){          //39
     return y + x + z;
     }
  public double sum(double y, int x, double z){          //40
     return y + x + z;
     }
  public double sum(double y, double x){           //41
     return y + x ;
     }
  public double sum(double y, double x, double z){    //42
     return y + x + z;
     }
  public double sum(short x, double y){                  //43
     return x+ y;
   }
  
	public double sum(float x, double y){                    //44
     return x+ y;
   }
	public double sum(double y, float x){              //45
     return x+ y;
   }
	public double sum(short x, double y, double z){          //46
     return x+ y + z;
   }
  public double sum(double x, short y, double z){           //47
    return x+ y;
    }
	public double sum(double x, double y, short z){          //48
     return x+ y;
    }
	public double sum(double x, short y, short z){           //49
      return x+ y;
    }
	public double sum(short x, double y, short z){              //50
      return x+ y;
    }
	public double sum(short x, short y, double z){           //51
      return x+ y;
    }
   public double sum(double x, float y, int z){             //52
       return x+ y;
    }
	public double sum(double x, float y, short z){              //53
        return x+ y;
    }
	public double sum(float x, double y, int z){             //54
        return y+ z;
    }
	public double sum(float x, double y, short z){         //55
       return y+ z;
    }
	public double sum(int x, float y, double z){           //56
       return x+ y + z;
    }
	public double sum(short x, float y, double z){         //57
       return x+ y + z;
    }
   public double sum(float x, double y, double z){       //58
      return x+ y + z;
    }
	public double sum(double x, float y, double z){        //59
         return x+ y + z;
    }
	public double sum(double x, double y, float z){    //60    
         return x+ y + z;
    }
	public double sum (double x, float y, float z){ 
   return x+ y + z;
    }                                                  //61
	public double sum(float x, double y, float z){      //62
      return x+ y + z;
    }
	public double sum(float x, float y, double z){         //63
      return x+ y + z;
    }
	// double with ints
  
	
	public double sum(double x, double y, int z){       
      return x+ y + z;
    }
	public double sum(int x, int y, double z){         //66
      return x+ y + z;
    }
	
	public double sum(double x, int y, int z){      //67
       return x+ y + z;
    }

  public double sumy(short x, double y, double z){   //68
     return x+ y + z;
    }
	
   


     }//end
     
   
     
     
  