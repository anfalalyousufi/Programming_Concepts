//********************************************************************************
// Multiply.java
//
// Name:Anfal AlYousufi
// Date: 19th of Nov 2015
// LAB_09
//********************************************************************************

public interface Multiply 
{
	// short, short x2 x3
	public short multiply(short x, short y);

	public short multiply(short x, short y, short z);

	// int
	public int multiply(int x, int y);

	// int with short
	public int multiply(short x, int y);
      
	public int multiply(int x, short y);

	// int
	public int multiply(int x, int y, int z);

	// int with short
	public int multiply(short x, int y, int z);

	public int multiply(int x, short y, int z);

	public int multiply(int x, int y, short z);

	public int multiply(short x, short y, int z);

	public int multiply(short x, int y, short z);

	public int multiply(int x, short y, short z);

	// float with float, int, short by 2
	public float multiply(short x, float y);

	public float multiply(float x, short y);

	public float multiply(float x, int y);

	public float multiply(int x, float y);

	public float multiply(float x, float y);

}