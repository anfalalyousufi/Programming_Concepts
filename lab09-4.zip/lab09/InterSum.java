//********************************************************************************
// InterSum.java
//
// Name:Anfal AlYousufi
// Date: 19th of Nov 2015
// LAB_09
//********************************************************************************

 public interface InterSum
   {
      
	// short, short x2 x3
	public int sum(short x, short y);
      
   public  int sum(short x, short y, short z);
   

	// int
	public int sum(int x, int y);
	// int with short
	public int sum(short x, int y);

	public int sum(int x, short y);
   
	// int
	public int sum(int x, int y, int z);
   

	// int with short
	public int sum(short x, int y, int z);

	public int sum(int x, short y, int z);
   
	public int sum(int x, int y, short z);

	public int sum(short x, short y, int z);

	public int sum(short x, int y, short z);

	public int sum(int x, short y, short z);
   
	// float with float, int, short by 2
	public float sum(short x, float y);
      
	public float sum(float x, short y);
     
	public float sum(float x, int y);

	public float sum(int x, float y);
   
	public float sum(float x, float y);
  
	// float by 3
	public float sum(float x, float y, float z);
   

	// float with int
	public float sum(int x, float y, float z);
   
	public float sum(float x, int y, float z);
   
	public float sum(float x, float y, int z);
   
   public float sum(int x, int y, float z);
      
	public float sum(int x, float y, int z);
      
	public float sum(float x, int y, int z);
      

	// float with short
	public float sum(short x, float y, float z);
      
   public float sum(float x, short y, float z);
      
	public float sum(float x, float y, short z);
      
	public float sum(short x, short y, float z);
      
	public float sum(short x, float y, short z);
     
	public float sum(float x, short y, short z);
     
	// float with short and int
	public float sum(short x, int y, float z);

	public float sum(int x, short y, float z);

	public float sum(short x, float y, int z);

	public float sum(int x, float y, short z);
 
	public float sum(float x, int y, short z);
   
	public float sum(float x, short y, int z);
   
	// doubles with double, float, int, shorts by 2
	public double sum(short x, double y);
 
	public double sum(double x, short y);
  
	public double sum(int x, double y);
  
	public double sum(double x, int y);
   
	public double sum(float x, double y);
     
	public double sum(double y, float x);
   
	public double sum(double x, double y);
    
	public double sum(double x, double y, double z);
     
	// double with float
	public double sum(float x, double y, double z);
      
	public double sum(double x, float y, double z);
    
	public double sum(double x, double y, float z);
 
	public double sum(double x, float y, float z);
 
	public double sum(float x, double y, float z);
   
	public double sum(float x, float y, double z);
    
	// double with ints
	public double sum(int x, double y, double z);
    
	public double sum(double x, int y, double z);
    
	public double sum(double x, double y, int z);
    
	public double sum(int x, int y, double z);
    
	public double sum(int x, double y, int z);
      
	public double sum(double x, int y, int z);
     
	// double with shorts
	public double sum(short x, double y, double z);
    
	public double sum(double x, short y, double z);

	public double sum(double x, double y, short z);

	public double sum(double x, short y, short z);

	public double sum(short x, double y, short z);

	public double sum(short x, short y, double z);

	// double, float, with int or short
	public double sum(double x, float y, int z);
   
	public double sum(double x, float y, short z);

	public double sum(float x, double y, int z);

	public double sum(float x, double y, short z);

	public double sum(int x, float y, double z);
     
	public double sum(short x, float y, double z);
    
  
}

