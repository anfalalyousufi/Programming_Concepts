//********************************************************************************
// RealSum.java
//
// Name:Anfal AlYousufi
// Date: 13th of Nov 2015
// LAB_09
//********************************************************************************

public class RealSum extends ZeroSum {

   @Override
    public int sum(int x, int y) {                       //1
		return x + y;
     }
   public int sum ( int y , short x ){                  //3
     int sum;
     return y + x ;
     }
	public int sum (int x, int y, int z) {               //2
      int sum;
      return x + y + z ;
	}
  
   public int sum( int y , short x, short z ){           //4
     int sum;
     return y + x + z;
     }
    public int sum( int y , short x, int z ){            //19
     int sum;
     return y + x + z;
     }
   public int sum( int y , int x, short z ){            //20
     int sum;
     return y + x + z;
     }
  
   public int sum( short y , int x, int z ){            //5
     int sum;
     return y + x + z;
     }
  
   // short 
   public int sum( short y , int x, short z ){          //6
     int sum;
     return y + x + z;
     }
   public int sum( short y , short x, int z ){            //7
     int sum;
     return y + x + z;
     }
   public int sum( short y , short x ){                    //8
     int sum;
     return y + x ;
     }
   public int sum( short y , int x ){                    //17
     int sum;
     return y + x ;
     }
   public int sum( short y , short x , short z ){         //18
     int sum;
     return y + x ;
     }
  
     // float
   public float sum ( float x , float y ){                //9
     float sum;
     return x + y ;
     }
   public float sum ( float x , float y, float z ){       //10
     float sum;
     return x + y + z;
     }
   public float sum ( float x , int y, float z ){          //11
     float sum;
     return x + y + z;
     }
    public float sum ( float x ,short y, short z ){       //12
     float sum;
     return x + y + z;
     }
   public float sum ( float x ,int y, short z ){         //13
     float sum;
     return x + y + z;
     }
   public float sum ( float x , int y, int z ){          //14
     float sum;
     return x + y + z;
     }
   public float sum ( float x ,int y ){                   //15
     float sum;
     return x + y ;
     }
   public float sum ( float x, short z ){                  //16
     float sum;
     return x + z;
     }
   public float sum ( short x, float z ){                  //16
     float sum;
     return x + z;
     }
   
  
     
     
     
     }//en
     
   