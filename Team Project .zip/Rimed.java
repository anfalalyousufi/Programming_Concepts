
public class Rimed extends SnowFlake {

	private int type=30;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
