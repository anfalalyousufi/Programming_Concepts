
public class BulletRosettes extends SnowFlake {

	private int type=12;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
