
public class RadiatingDendrites extends SnowFlake {

	private int type=20;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
