
public class NeedleClusters extends SnowFlake {

	private int type=27;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
