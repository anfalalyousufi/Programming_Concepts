
public class HollowColumns extends SnowFlake {

	private int type=7;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}
}
