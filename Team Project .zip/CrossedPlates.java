
public class CrossedPlates extends SnowFlake {

	private int type=34;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
