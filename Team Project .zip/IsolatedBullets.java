
public class IsolatedBullets extends SnowFlake {

	private int type=17;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
