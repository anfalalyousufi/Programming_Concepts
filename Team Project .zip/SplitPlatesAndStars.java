
public class SplitPlatesAndStars extends SnowFlake {

	private int type=14;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
