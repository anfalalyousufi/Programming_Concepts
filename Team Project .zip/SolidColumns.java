
public class SolidColumns extends SnowFlake {

	private int type=2;
	
	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}
}
