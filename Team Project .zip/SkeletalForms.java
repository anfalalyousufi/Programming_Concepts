
public class SkeletalForms extends SnowFlake {

	private int type=19;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
