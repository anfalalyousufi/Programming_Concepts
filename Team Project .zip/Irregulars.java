
public class Irregulars extends SnowFlake {

	private int type=25;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
