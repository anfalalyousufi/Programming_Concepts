
public class Sheaths extends SnowFlake {

	private int type=3;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
