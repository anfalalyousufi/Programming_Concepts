
public class SimplePrisms extends SnowFlake{
	
	private int type=1;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}
}