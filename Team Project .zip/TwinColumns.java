
public class TwinColumns extends SnowFlake {

	private int type=24;

	public double melt() {
		diameter=(diameter/(meltModifier+type));
		radius=diameter/2;
		return diameter;
	}

}
