//********************************************
//|    /\  | >    |  |''|
//|__ /  \ | >    |  |__| team project 02
//                        team #1
// SnowFlake.java
//********************************************

import java.util.Random;

public abstract class SnowFlake {
	
	static Random gen = new Random(System.currentTimeMillis());
	protected double diameter;
	protected double radius;
	protected double meltModifier=0.05;
	protected int type;
	static int snowFall=0;
	
	public SnowFlake()
	{
		diameter=gen.nextFloat()+(gen.nextInt(2)+8);
		radius=diameter/2;
		snowFall++;
	}
	
	public double getDiameter()
	{
		return diameter;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public int getType()
	{
		return type;
	}
	
	public abstract double melt();

	public String toString() {
		return "SnowFlake: diameter=" + diameter + ", radius=" + radius + ", type="
				+ type + "]";
	}
	
	
}
