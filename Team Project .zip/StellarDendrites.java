
public class StellarDendrites extends SnowFlake{

	private int type=26;
	
	public double melt() {
		diameter=diameter/(meltModifier+type);
		radius=diameter/2;
		return diameter;
	}
}
